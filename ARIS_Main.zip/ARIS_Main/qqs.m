% File: InitData_GTMR_4_Nonlin.m
function [input, data] = InitData(settings)
    %% Pull dims from settings
    nx       = settings.nx;
    nu       = settings.nu;
    nz       = settings.nz;
    ny       = settings.ny;
    nyN      = settings.nyN;
    np       = settings.np;
    nc       = settings.nc;
    ncN      = settings.ncN;
    N        = settings.N;
    nbx      = settings.nbx;
    nbu      = settings.nbu;
    nbx_idx  = settings.nbx_idx;
    nbu_idx  = settings.nbu_idx;

    switch settings.model
        case 'GTMR_4_Nonlin'
            %% Initial conditions
            input.x0 = [ 0;0;100;   ...  % p start
                         1;0;0;0.;   ...  % q start
                         0;0;0;   ...  % v start
                         0;0;0; 10^5 ];      % ω start
            input.u0 = [0;0;0;0];      % Ω start
            input.z0 = zeros(nz,1);
            para0   = zeros(np,1);

            %% Tracking target
            data.final_p = [5;5;100];
            data.final_v = [0;0;0];

            %% Weights
            q_0=[1;1;1; 0.1;0.1;0.1];
            Q  = repmat(q_0,1,N);
            QN =    q_0;   
            data.q_0=q_0;
            %% Bounds on states (none) and controls Ω_i ≥ 0
            lb_x = [-40;-40;-140;0];
            ub_x = [40;40;140;inf];
            lb_u = [0;-4;-4;-0.2];
            ub_u = [30;4;4;0.2];
            lb_g = [0];
            ub_g = [inf];
            lb_gN= [0];
            ub_gN= [inf];
    end

    %% General path constraint bounds
    input.lb = repmat(lb_g,N,1);
    input.ub = repmat(ub_g,N,1);
    input.lb = [input.lb; lb_gN];
    input.ub = [input.ub; ub_gN];

    %% Control bounds
    lbu = -inf(nu,1);
    ubu =  inf(nu,1);
    for i = 1:nbu
        lbu(nbu_idx(i)) = lb_u(i);
        ubu(nbu_idx(i)) = ub_u(i);
    end
    input.lbu = repmat(lbu,1,N);
    input.ubu = repmat(ubu,1,N);

    %% State bounds
    lbx = -inf(nbx,1);
    ubx =  inf(nbx,1);
    for i = 1:nbx
        lbx(i) = lb_x(i);
        ubx(i) = ub_x(i);
    end
    input.lbx = repmat(lbx,1,N);
    input.ubx = repmat(ubx,1,N);

    %% Shooting arrays
    input.x  = repmat(input.x0,1,N+1);
    input.u  = repmat(input.u0,1,N);
    input.z  = repmat(input.z0,1,N);
    input.od = repmat(para0,1,N+1);

    %% Weights
    input.W  = Q;
    input.WN = QN;

    %% Multipliers
    input.lambda = zeros(nx,N+1);
    input.mu     = zeros(N*nc+ncN,1);
    input.mu_u   = zeros(N*nu,1);
    input.mu_x   = zeros(N*nbx,1);

    %% Reference matrix
    %data.REF = repmat([data.final_p; data.final_v]',N+1,1);
    data.REF=[data.final_p; data.final_v]';
end